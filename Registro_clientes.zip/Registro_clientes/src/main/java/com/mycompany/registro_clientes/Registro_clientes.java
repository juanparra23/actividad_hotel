/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registro_clientes;

import java.util.Scanner;
import com.mycompany.registro_clientes.Cliente;
/**
 *
 * @author user
 */
public class Registro_clientes {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
          System.out.println("Registro cliente");
            Cliente cliente1 = new Cliente ();
            
        
            
    
            cliente1.setNombre("juan ignaico");
            cliente1.setEdad(19);
            cliente1.getLocation();
            cliente1.getCel();
           
            System.out.println(cliente1.toString()+ "");
            
        
    }
  
        
}