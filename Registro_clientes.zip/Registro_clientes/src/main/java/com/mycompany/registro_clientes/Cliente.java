/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registro_clientes;
import java.util.Scanner;
/**lien
 *
 * @author user
 */
public class Cliente {
    private String nombre;
    private String cc;
    private int  edad;
    private String location;
    public String cel;
    
    public Cliente(){
        
    }
    
    public Cliente(String nombre, String cc, int edad, String location, String cel ){
        this.nombre =nombre;
        this.cc = cc;
        this.edad = edad;
        this.location = location;
        this.cel  = cel;
        
     
      
    
    }
  

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getId() {
        return cc;
    }

    public void setId(String cc) {
        this.cc = cc;
    }
    
    
    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCel() {
        return cel;
    }

    public void setCel(String cel) {
        this.cel = cel;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", cc=" + cc + ", edad=" + edad + ", location=" + location + ", cel=" + cel + '}';
    }

    void getEdad(int nextInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}
